 /* calc.h: header file for calc.c. */

 long sqr(int x);

 /* end of calc.h */
