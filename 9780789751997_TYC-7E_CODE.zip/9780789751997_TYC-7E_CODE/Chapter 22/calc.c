 /* Module containing calculation functions. */

 #include "calc.h"

 long sqr(int x)
 {
    return ((long)x * x);
 }
